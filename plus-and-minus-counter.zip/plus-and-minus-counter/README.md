# Plus and Minus Counter

A Pen created on CodePen.

Original URL: [https://codepen.io/Carolina-Ramirez/pen/bNEPGVX](https://codepen.io/Carolina-Ramirez/pen/bNEPGVX).

Just a counter with plus and minus buttons